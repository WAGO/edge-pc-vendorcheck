#!/bin/bash
# Contact: Helmut.Saal@wago.com
SCRIPTVERSION=1.0.0
# Script to configure CAA that library licences validation could be read
# Script modified CODE..._USER.conf so that /tmp/ read would be allowed

#Vars
CAA_TARGET_FOLDER="/var/opt/codesysvcontrol/instances/"
CAA_FILE="/conf/codesyscontrol/CODESYSControl_User.cfg"
DB_FOLDER="/root/.vendorcheck/"
NEW_FOLDERS="newfolder.txt"
MODIFIED_FOLDERS="modifyedfolder.txt"
newfolderARRAY=()
modifiedfolderARRAY=()
configfolderARRAY=()
DEBUG=0
TIME=5

# Check how many instances (folders) are created
function checkFolder()
{
    /etc/init.d/info
    deleteArray
    mkdir /root/.vendorcheck 2> /dev/null
    FIND_PATH=`find $CAA_TARGET_FOLDER -maxdepth 1 -mindepth 1 -type d`
    echo $(rm $DB_FOLDER$NEW_FOLDERS 2> /dev/null)
    k=0
    for i in ${FIND_PATH[@]}
    do
        newfolderARRAY[$k]="$i$CAA_FILE"
        echo "$i$CAA_FILE" >> $DB_FOLDER$NEW_FOLDERS
        (( k++ ))
    done
    modifiedFolder
}
function modifiedFolder()
{    
# Read modifyfile if exists    
    if [ -e $DB_FOLDER$MODIFIED_FOLDERS ] ; 
    then
        if [ $DEBUG -eq 1 ]
        then
            echo "$DB_FOLDER$MODIFIED_FOLDERS exists, configure only different folders."
        fi
        # Read modifiedfolder and create modifiedArray
        FIND_ENTRY=`cat $DB_FOLDER$MODIFIED_FOLDERS`
        k=0
        for i in ${FIND_ENTRY[@]}
        do
            modifiedfolderARRAY[$k]="$i"     
            (( k++ ))
        done
        # Create diff Array of entrys to configure and write into modifiedfolder
        FIND_ENTRY=`echo ${newfolderARRAY[@]} ${modifiedfolderARRAY[@]} | tr ' ' '\n' | sort | uniq -u`
        k=0
        for i in ${FIND_ENTRY[@]}
        do
            configfolderARRAY[$k]="$i"     
            (( k++ ))
            # Configure function => CAA.conf
            modifyConf "$i"
            # Write into modifiedfolder.txt
            echo "$i" >> $DB_FOLDER$MODIFIED_FOLDERS
        done
    else
        if [ $DEBUG -eq 1 ]
        then
            echo "$DB_FOLDER$MODIFYED_FOLDERS not found, configure all."
        fi
        FIND_ENTRY=`cat $DB_FOLDER$NEW_FOLDERS`
        for i in ${FIND_ENTRY[@]}
        do
            modifyConf "$i"
            echo "$i" >> $DB_FOLDER$MODIFIED_FOLDERS  
        done
    fi
    # LOOP
    sleep $TIME
    checkFolder
}
function modifyConf()
{
    # Modify File here
    # Test File if Entry exists
    ENTRY=$(cat "$1" | grep FilePath)
    if [ -z "$ENTRY" ]
    then
        if [ $DEBUG -eq 1 ]
        then
        echo "Eintrag in $1 nicht vorhanden, modifiziere .conf"
        fi
        sed -i '/;virtuallinux/a [SysFile]\nFilePath=/tmp/, .error.crc\n' "$1"
        ####sed -i '1,/';virtuallinux'/a [SysFile]/nFilePath=/tmp/, .error.crc' "$1"
    else
        if [ $DEBUG -eq 1 ]
        then
            echo "Eintrag in $1 vorhanden => idle"
        fi
    fi
}
function deleteArray()
{
    if [ $DEBUG -eq 1 ]
    then
        echo "Delete all Arrays...."
    fi
    newfolderARRAY=()
    modifiedfolderARRAY=()
    configfolderARRAY=()
}
checkFolder
